package preguntas;

import java.util.Scanner;

public class Preguntas {
    
    public static void main(String[] args) {
        
        Scanner scanner = new Scanner(System.in);
        String cadena;
        
    do {
       
        System.out.println("Ingrese una pregunta:");
        
        cadena = scanner.nextLine();
        
        if (cadena.contains("temporizador")&& cadena.contains("que")&& cadena.contains("es")) { //1
            System.out.println("Un temporizador en Java NetBeans es un objeto que puede ser programado para ejecutar una acción después de cierto tiempo.");
        } else {
        
            if (cadena.contains("temporizador")&& cadena.contains("como")&& cadena.contains("crea")) { //2
            System.out.println("Para crear un temporizador en Java NetBeans, es necesario instanciar la clase Timer y proporcionarle un intervalo de tiempo y un objeto ActionListener que definirá la acción a ejecutar.");
            } else {
                
                if (cadena.contains("unidad")&& cadena.contains("tiempo")&& cadena.contains("temporizador")){ //3
                System.out.println("El intervalo de tiempo de un temporizador en Java NetBeans se especifica en milisegundos.");
                } else {
                    
                    if (cadena.contains("inicia")&& cadena.contains("temporizador")&& cadena.contains("como")){ //4
                    System.out.println("Para iniciar un temporizador en Java Netbeans, se llama al método start() del objeto timer.");
                    } else {
                        
                        if (cadena.contains("detiene")&& cadena.contains("temporizador")&& cadena.contains("como")){ //5
                        System.out.println("Para detener un temporizador en Java Netbeans, se llama al método stop() del objeto timer.");
                        } else{
                            
                            if (cadena.contains("actionlistener")&& cadena.contains("que")&& cadena.contains("es")){ //6
                            System.out.println("Un ActionListener en Java NetBeans es una interfaz que define un método actionPerformed(ActionEvent e) que será llamado cuando se produzca una acción, como el evento generado por un temporizador.");
                            } else {
                                
                                if (cadena.contains("actionlistener")&& cadena.contains("implementa")&& cadena.contains("como")){ //7
                                System.out.println("Para implementar un ActionListener en Java NetBeans, se debe crear una clase que implemente la interfaz ActionListener y se sobrescriba el método actionPerformed().");
                                } else {
                                    
                                    if (cadena.contains("actionlistener")&& cadena.contains("añade")&& cadena.contains("temporizador")){ //8
                                    System.out.println("Para añadir un ActionListener a un temporizador en Java NetBeans, se llama al método addActionListener() del objeto Timer y se le pasa como argumento una instancia de la clase que implementa la interfaz ActionListener.");
                                    } else {
                                        
                                        if (cadena.contains("define")&& cadena.contains("acción")&& cadena.contains("temporizador")&& cadena.contains("ejecutar")){ //9
                                        System.out.println("La acción a ejecutar por un temporizador en Java Netbeans se define en el método actionPerformed() de la clase que implementa la interfaz ActionListener.");
                                        } else {
                                            
                                            if (cadena.contains("define")&& cadena.contains("intervalo")&& cadena.contains("temporizador")&& cadena.contains("tiempo")){ //10
                                            System.out.println("El intervalo de tiempo de un temporizador en Java Netbeans se define al instanciar la clase Timer y proporcionarle como argumento el intervalo de tiempo en milisegundos.");
                                            } else{
                                                
                                                if (cadena.contains("define")&& cadena.contains("intervalo")&& cadena.contains("temporizador")&& cadena.contains("tiempo")&& cadena.contains("sucede")&& cadena.contains("cero")&& cadena.contains("igual")){ //11
                                                System.out.println("Si se define un intervalo de tiempo igual a cero en un temporizador en Java NetBeans, la acción se ejecutará inmediatamente una sola vez.");
                                                } else {
                                                    
                                                    if (cadena.contains("verifica")&& cadena.contains("ejecución")&& cadena.contains("temporizador")){ //12
                                                    System.out.println("Para verificar si un temporizador en Java Netbeans está en ejecución, se llama al método isRunning() del objeto Timer, que devolverá un valor booleano.");
                                                    } else {
                                                        
                                                        if (cadena.contains("timertask")&& cadena.contains("que")&& cadena.contains("es")){ //13
                                                        System.out.println("Un TimerTask en Java Netbeans es una clase abstracta que implementa la interfaz Runnable y define un método run() que se ejecutará cuando se programe un temporizador.");
                                                        } else {
                                                            
                                                            if (cadena.contains("timertask")&& cadena.contains("programa")&& cadena.contains("como")&& cadena.contains("java")&& cadena.contains("netbeans")){ //14
                                                            System.out.println("Para programar un TimerTask en Java NetBeans, se crea una instancia de la clase que extiende TimerTask y se llama al método schedule() del objeto Timer, pasándole como argumento la instancia de Timer.");
                                                            } else {
                                                                
                                                                if (cadena.contains("temporizador")&& cadena.contains("ejecute")&& cadena.contains("programa")&& cadena.contains("solo")&& cadena.contains("una")){ //15
                                                                System.out.println("Para programar un temporizador que se ejecute solo una vez en Java NetBeans, se define el intervalo de tiempo en milisegundos igual a cero.");
                                                                } else {
                                                                    
                                                                    if (cadena.contains("temporizador")&& cadena.contains("repita")&& cadena.contains("programa")&& cadena.contains("indefinidamente")){ //16
                                                                    System.out.println("Par programar un temporizador que se repita indefinidamente en Java Netbeans, se define el intervalo de tiempo en milisegundos y se llama método setRepeats(true) del objeto Timer.");
                                                                    } else {
                                                                        
                                                                        if (cadena.contains("temporizador")&& cadena.contains("repita")&& cadena.contains("programa")&& cadena.contains("numero")&& cadena.contains("determinado")){ //17
                                                                        System.out.println("Para programar un temporizador que se repita un número determinado de veces en Java NetBeans, se llama al método setRepeats(false) del objeto Timer después de que el temporizador haya sido activado un número determinado de veces.");
                                                                        } else {
                                                                            
                                                                            if (cadena.contains("temporizador")&& cadena.contains("cantidad")&& cadena.contains("activado")){ //18
                                                                            System.out.println("Para obtener la cantidad de veces que se ha activado un temporizador en Java NetBeans, se llama al método getActionCommand() del objeto ActionEvent que es recibido por el método ActionPerformed() de la clase IF implementa ActionListener.");
                                                                            } else {
                                                                                
                                                                                if (cadena.contains("temporizador")&& cadena.contains("cambia")&& cadena.contains("intervalo")&& cadena.contains("tiempo")){ //19
                                                                                System.out.println("Para cambiar el intervalo de tiempo de un temporizador en Java NetBeans después de haber sido programado, se llama al método setDelay() del objeto Timer y se le pasa como argumento el nuevo intervalo de tiempo en milisegundos.");
                                                                                } else {
                                                                                    
                                                                                    if (cadena.contains("temporizador")&& cadena.contains("como")&& cadena.contains("pausa")&& cadena.contains("java")){ //20
                                                                                    System.out.println("Para pausar un temporizador en Java NetBeans, se llama al método stop() del objeto Timer.");
                                                                                    } else {
                                                                                        
                                                                                        if (cadena.contains("temporizador")&& cadena.contains("como")&& cadena.contains("reanuda")&& cadena.contains("java")){ //21
                                                                                        System.out.println("Para reanudar un temporizador pausado en Java Netbeans, se llama al método start() del objeto Timer.");
                                                                                        } else {
                                                                                            
                                                                                            if (cadena.contains("temporizador")&& cadena.contains("como")&& cadena.contains("reinicia")&& cadena.contains("java")){//22
                                                                                            System.out.println("Para reiniciar un temporizador en Java NetBeans, se llama al método stop() y luego se llama al método start() del objeto Timer.");
                                                                                            } else {
                                                                                                
                                                                                                if (cadena.contains("temporizador")&& cadena.contains("obtener")&& cadena.contains("estado")&& cadena.contains("actual")){ //23
                                                                                                System.out.println("Para obtener el estado actual de un temporizador en Java NetBeans, se llama al método isRunning() del objeto Timer, que devuelve un valor booleano que indica si el temporizador está en ejecución o no.");
                                                                                                } else {
                                                                                                    
                                                                                                    if (cadena.contains("temporizador")&& cadena.contains("prioridad")&& cadena.contains("hilo")){ //24
                                                                                                    System.out.println("La prioridad del hilo de un temporizador en Java NetBeans se especifica al instanciar la clase Timer y proporcionarle un valor de prioridad de hilo como argumento.");
                                                                                                    } else {
                                                                                                        
                                                                                                        if (cadena.contains("temporizador")&& cadena.contains("define")&& cadena.contains("automaticamente")&& cadena.contains("número")&& cadena.contains("determinado")){ //25
                                                                                                        System.out.println("Para detener un temporizador automáticamente después de un número determinado de repeticiones en Java NetBeans, se llama al método setRepeats(false) del objeto Timer después de que el temporizador haya sido activado un número determinado de veces.");
                                                                                                        } else {
                                                                                                            
                                                                                                            if (cadena.contains("temporizador")&& cadena.contains("especifica")&& cadena.contains("acción")&& cadena.contains("ejecutar")&& cadena.contains("activa")){ //26
                                                                                                            System.out.println("Se debe implementar la interfaz ActionListener y su método actionPerformed(). Luego, se crea un objeto Timer y se le pasa la acción a ejecutar como un parámetro en el constructor.");
                                                                                                            } else {
                                                                                                                
                                                                                                                if (cadena.contains("timertick")&& cadena.contains("que")&& cadena.contains("es")){ //27
                                                                                                                    System.out.println("TimerTick es un evento que se produce cada vez que el temporizador de Java NetBeans se activa.");
                                                                                                                } else {
                                                                                                                    
                                                                                                                    if (cadena.contains("cambia")&& cadena.contains("intervalo")&& cadena.contains("ejecutando")&& cadena.contains("temporizador")){ //28
                                                                                                                    System.out.println("Para cambiar el intervalo de tiempo de un temporizador mientras se está ejecutando en Java NetBeans, se llama al método setDelay() del objeto Timer y se le pasa como argumento el nuevo intervalo de tiempo en milisegundos.");
                                                                                                                    } else {
                                                                                                                        
                                                                                                                        if (cadena.contains("detiene")&& cadena.contains("temporizador")&& cadena.contains("ejecuta")&& cadena.contains("segundo")){ //29
                                                                                                                        System.out.println("Para detener un temporizador que se ejecuta en segundo plano en Java NetBeans, se llama al método stop() del objeto Timer.");
                                                                                                                        } else {
                                                                                                                            
                                                                                                                            if (cadena.contains("evita")&& cadena.contains("temporizador")&& cadena.contains("funcionando")&& cadena.contains("ventana")){ //30
                                                                                                                            System.out.println("Para evitar que un temporizador en Java NetBeans siga funcionando después de cerrar la ventana principal, se debe llamar al método stop() del objeto Timer en el método windowClosing() del objeto JFrame o JDialog que contiene el temporizador. De esta forma, se asegura que el temporizador se detenga antes de cerrar la ventana.");
                                                                                                                            }
                                                                                                                            else
                                                                                                                            {
                                                                                                                                if (cadena.contains(" ")){
                                                                                                                                    System.out.println("No se reconoce la pregunta");
                                                                                                                                }
                                                                                                                            }
                                                                                                                        }
                                                                                                                    }
                                                                                                                }
                                                                                                            }
                                                                                                        }
                                                                                                    }
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }   
                        }   
                    } 
                }
            }
        }
        } while (!cadena.equalsIgnoreCase("salir"));   
    }
}
