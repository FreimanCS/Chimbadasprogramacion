
package formulario;

import java.io.FileWriter;
import java.io.IOException;
import com.opencsv.CSVWriter;

public class Formulario {
        
    public static void main(String[] args) {
    
    }
    public void guardarDatosEnCSV(String[] datosFormulario) {
    // Ruta y nombre del archivo CSV
    String rutaArchivo = "datos.csv";

    try {
        // Crear un FileWriter con la ruta del archivo
        FileWriter fileWriter = new FileWriter(rutaArchivo, true);

        // Crear un CSVWriter utilizando el FileWriter
        CSVWriter csvWriter = new CSVWriter(fileWriter);

        // Escribir los datos en el archivo CSV
        csvWriter.writeNext(datosFormulario);

        // Cerrar el CSVWriter
        csvWriter.close();

        System.out.println("Los datos se han guardado correctamente en el archivo CSV.");
    } catch (IOException e) {
        System.err.println("Error al guardar los datos en el archivo CSV: " + e.getMessage());
    }
}

    
}
